<?php get_header(); ?>
<div class="container">
<div id="tabber-BX">
     <div class="LayoutContent-70 fullwidth">  
         <div class="SitePageStyle-2">              
			<?php woocommerce_content(); ?>
          </div><!-- .SitePageStyle-2-->           
    </div><!-- LayoutContent-70-->   
</div><!-- #tabber-BX --> 
</div><!-- .container -->     
<?php get_footer(); ?>