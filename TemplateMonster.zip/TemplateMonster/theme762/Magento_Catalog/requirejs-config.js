/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {}
    },
    paths: {
        "catalogAddToCartCustom":      'Magento_Catalog/js/catalog-add-to-cart-custom',
    }
};

